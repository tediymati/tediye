# addmefast

0.0.7
- added soundcloud support ( follow & like )
- added youtube support ( subscribe & like )
- fix tiktok like

0.0.6
- fix tiktok like

0.0.5
- added twitter support ( follow & like )

AddMeFast is a network that will help you grow your social presence, allow you to look and choose who you want to like/subscribe/follow/view and skip those who you are not interested in. 
you can get free points by liking/following/viewing/subscribing/listening the others pages/accounts/videos/profiles/music. 
The points you get will be used to increase likes/views/shares and others on your social media accounts such as Facebook, Twitter, Instagram, TikTok, YouTube and many more.

*** YOU MUST USE ENGLISH LAYOUT FOR YOUR DUMMY SOCIAL MEDIA ACCOUNT ***

*** YOU HAVE TO ALLOW POPUP FOR ADDMEFAST SITE IN CHROME/EDGE/OPERA SETTINGS !!! ***


use dummy account instead of main account to get points
- if you use instagram account to gain points, YOU HAVE TO LOGOUT AND LOGIN AGAIN (INSTAGRAM ACCOUNT RELOGIN)

How to use and Demo : https://www.youtube.com/watch?v=_DTZEEoTzZk

if you have any questions please leave a comment on youtube :)

I really hope for your support by subscribing to my youtube channel :
https://www.youtube.com/channel/UCqRqvw9n7Lrh79x3dRDOkDg

note: The extension may not work in the future if tiktok/instagram/facebook/twitter/soundcloud/youtube/addmefast change their layout, in this case, you should subscribe my channel to get an update for the new script.
